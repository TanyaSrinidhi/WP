        <div id="M1">
            <img id="M1" src="http://ia.media-imdb.com/images/M/MV5BMTQ1NDI2MzU2MF5BMl5BanBnXkFtZTgwNTExNTU5NDE@._V1_SX214_AL_.jpg" alt="Movie image broken" width="200" height="300">
			<a href="#openModal">
            <p class="p1">MISSION IMPOSSIBLE: ROGUE NATION</p></a>
            <p>Age Guidance: PG-13</p>
            <p>Ethan and team take on their most impossible mission yet, eradicating the Syndicate - an International rogue organization as highly skilled as they are, committed to destroying the IMF.</p>
            <p class="p4">TIMINGS:</p>
            <p>WED-FRI:     9PM</p>
            <p>SAT-SUN:     9PM</p>
			     
		
            <div id="openModal" class="modalDialog">
			 <div>
			 <a href="#close" title="Close" class="close">X</a>
			 <h2>SUMMARY</h2>
			 <p>CIA chief Hunley (Baldwin) convinces a Senate committee to disband the IMF (Impossible Mission Force), of which Ethan Hunt (Cruise) is a key member.</p>
			 <p>Hunley argues that the IMF is too reckless. Now on his own, Hunt goes after a shadowy and deadly rogue organization called the Syndicate.</p>
	
		      </div>
		    </div>
            <div id="book"><a id="link" href="./bookform.php">BOOK</a></div>
        </div>
        
        
        <div id="M1">
            <img id="M1" src="http://ia.media-imdb.com/images/M/MV5BMjM2NTQ5Mzc2M15BMl5BanBnXkFtZTgwNTcxMDI2NTE@._V1_SX214_AL_.jpg" alt="Movie image broken" width="200" height="300">
			<a href="#openModal2">
            <p class="p1">ANT-MAN</p></a>
            <p>Age Guidance: PG-13</p>
            <p>Armed with a super-suit with the astonishing ability to shrink in scale but increase in strength, cat burglar Scott Lang must embrace his inner hero and help his mentor, Dr. Hank Pym, plan and pull off a heist that will save the world.</p>
            <p class="p4">TIMINGS:</p>
            <p>MON-TUES:    1PM</p>
            <p>WED-FRI:     6PM</p>
            <p>SAT-SUN:     12PM</p>
			
		<div id="openModal2" class="modalDialog">
		  <div>
              <a href="#close" title="Close" class="close">X</a>
			  <h2>SUMMARY</h2>
			      <p>Armed with the astonishing ability to shrink in scale but increase in strength, con-man Scott Lang must embrace his inner-hero and help his mentor, Dr. Hank Pym, protect the secret behind his spectacular Ant-Man suit from a new generation of towering threats.</p> 
			       <p>Against seemingly insurmountable obstacles, Pym and Lang must plan and pull off a heist that will save the world.</p>				  </div>
		</div>
			
			
            <div id="book"><a id="link" href="./bookform.php">BOOK</a></div>
        </div>
        
        <div id="M1">
            <img id="M1" src="http://ia.media-imdb.com/images/M/MV5BNzAzMjA1ODAxOV5BMl5BanBnXkFtZTgwODg4NTQzNDE@._V1_SX214_AL_.jpg" alt="Movie image broken" width="200" height="300">
			<a href="#openModal3">
            <p class="p1">WILD TALES</p></a>
            <p>Age Guidance: R</p>
            <p>Six short stories involving distressed people.</p>
            <p class="p4">TIMINGS:</p>
            <p>MON-TUES:    6PM</p>
            <p>SAT-SUN:     3PM</p>
			
			
		<div id="openModal3" class="modalDialog">
		<div>
			<a href="#close" title="Close" class="close">X</a>
			<h2>SUMMARY</h2>
			<p>Six dark stories, involved six savage situations full of revenge and dark sides of human being- such as dreadful revenge to hated person- accidental or intentional, dangerous and unexpected arguments or misunderstood, and fearful conversations and deals, which changed the lives of people who involved in.</p>
		</div>
		</div>
			
			<div id="book"><a id="link" href="./bookform.php">BOOK</a></div>
        </div>
        
        <div id="M1">
            <img id="M1" src="http://ia.media-imdb.com/images/M/MV5BMTQ4MjgwNTMyOV5BMl5BanBnXkFtZTgwMTc1MjI0NDE@._V1_SX214_AL_.jpg" alt="Movie image broken" width="200" height="300">
			<a href="#openModal4">
            <p class="p1">TRAINWRECK</p></a>
            <p>Age Guidance: R</p>
            <p>Having thought that monogamy was never possible, a commitment-phobic career woman may have to face her fears when she meets a good guy.</p>
            <p class="p4">TIMINGS:</p>
            <p>MON-TUES:    9PM</p>
            <p>WED-FRI:     1PM</p>
            <p>SAT-SUN:     6PM</p>         

		<div id="openModal4" class="modalDialog">
		<div>
			<a href="#close" title="Close" class="close">X</a>
			<h2>SUMMARY</h2>
			<p>Since she was a little girl, it's been drilled into Amy's head by her rascal of a dad that monogamy isn't realistic. Now a magazine writer, Amy lives by that credo - enjoying what she feels is an uninhibited life free from stifling, boring romantic commitment - but in actuality, she's kind of in a rut.</p> 
			<p>When she finds herself starting to fall for the subject of the new article she's writing, a charming and successful sports doctor named Aaron Conners, Amy starts to wonder if other grown-ups, including this guy who really seems to like her, might be on to something.</p>
			
	
		</div>
        </div>
         <div id="book"><a id="link" href="./bookform.php">BOOK</a></div>                        

		</div>