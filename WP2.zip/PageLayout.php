<!--link rel="stylesheet" type="text/css" href="./WP1.css"-->
<div class="top">
	<img id="logo" src="./logo.png" alt="Logo image broken" width="50" height="50">
        <h1> <a id="header" href="HomePage.php">SILVERADO CINEMAS </a></h1>
</div>

<div class="side">
	<ul>
      <li> <a href=""></a></li>
   	  <li> <a href="./bookamovie.php">BOOK A MOVIE</a> </li>
	  <li> <a href="./SessionPage.php">SESSIONS</a> </li>
	  <li> <a href="./ContactPage.php">CONTACT</a> </li>	  
	</ul>
</div>

    
