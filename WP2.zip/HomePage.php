<? php
    session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="./WP1.css">
	<title> Silverado Cinemas </title>
</head>

<body>
    
    
    <?php 
        include 'PageLayout.php';
    ?>
        


    <div class="one">
        <div class="two">
            <p>NEW SEATS</p>
        </div>
		<img src="http://www.sott.net/image/s2/40397/medium/alg_theatre_seats.jpg" alt="Seats image broken" width="300" height="400">        
	</div>
	
    
    
	<div class="one">
        <div class="two">
            <p>DOLBY SPEAKERS</p>
        </div>
		<img src="http://static1.squarespace.com/static/52c86b19e4b0df7dc79cd177/t/52cce4c1e4b0b567eecbd64b/1389159619285/Dolby_image.jpg?format=1500w" alt="DOLBY image broken" width="300" height="400">
	</div>

	<div class="one">
        <div class="two">
            <p>3D THEATRE</p>
        </div>
		<img src="http://3dvision-blog.com/wp-content/uploads/2009/12/3d-cinema-theatre.jpg" alt="3d image broken" width="300" height="400">
	</div>
    

	<div id="box">
        <div class="two">
		  <p> NOW SHOWING </p>
        </div>
	</div>
    
	<div class="img">
        <div class="M1">
		  <img class="M1" src="http://ia.media-imdb.com/images/M/MV5BMTQ1NDI2MzU2MF5BMl5BanBnXkFtZTgwNTExNTU5NDE@._V1_SX214_AL_.jpg" alt="3d image broken" width="200" height="300">
        </div>
    </div>
    
    <div class="img">
        <div class="M2">
		  <img class="M2" src="http://ia.media-imdb.com/images/M/MV5BMjM2NTQ5Mzc2M15BMl5BanBnXkFtZTgwNTcxMDI2NTE@._V1_SX214_AL_.jpg" alt="3d image broken" width="200" height="300">
        </div>
    </div>
    
    <div class="img">
        <div class="M3">
		  <img class="M3" src="http://ia.media-imdb.com/images/M/MV5BNzAzMjA1ODAxOV5BMl5BanBnXkFtZTgwODg4NTQzNDE@._V1_SX214_AL_.jpg" alt="3d image broken" width="200" height="300">
        </div>
    </div>
    
    <div class="img">
        <div class="M4">
		  <img class="M4" src="http://ia.media-imdb.com/images/M/MV5BMTQ4MjgwNTMyOV5BMl5BanBnXkFtZTgwMTc1MjI0NDE@._V1_SX214_AL_.jpg" alt="3d image broken" width="200" height="300">
	   </div>
    </div>

    
    <?php include 'Footer.php' ?>


</body>
    
</html>

